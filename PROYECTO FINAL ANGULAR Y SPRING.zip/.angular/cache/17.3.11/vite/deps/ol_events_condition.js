import {
  all,
  altKeyOnly,
  altShiftKeysOnly,
  always,
  click,
  doubleClick,
  focus,
  focusWithTabindex,
  mouseActionButton,
  mouseOnly,
  never,
  noModifierKeys,
  penOnly,
  platformModifierKey,
  platformModifierKeyOnly,
  pointerMove,
  primaryAction,
  shiftKeyOnly,
  singleClick,
  targetNotEditable,
  touchOnly
} from "./chunk-AS5CBGY2.js";
import "./chunk-4MAB2MYE.js";
import "./chunk-APGPI4FP.js";
import "./chunk-CPNXOV62.js";
export {
  all,
  altKeyOnly,
  altShiftKeysOnly,
  always,
  click,
  doubleClick,
  focus,
  focusWithTabindex,
  mouseActionButton,
  mouseOnly,
  never,
  noModifierKeys,
  penOnly,
  platformModifierKey,
  platformModifierKeyOnly,
  pointerMove,
  primaryAction,
  shiftKeyOnly,
  singleClick,
  targetNotEditable,
  touchOnly
};
//# sourceMappingURL=ol_events_condition.js.map
