import {
  BaseDecoder
} from "./chunk-JCX666RU.js";
import "./chunk-CPNXOV62.js";

// node_modules/geotiff/dist-module/compression/raw.js
var RawDecoder = class extends BaseDecoder {
  decodeBlock(buffer) {
    return buffer;
  }
};
export {
  RawDecoder as default
};
//# sourceMappingURL=raw-ZXHE5ATX.js.map
