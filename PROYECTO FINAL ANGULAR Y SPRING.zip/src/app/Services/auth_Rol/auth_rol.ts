import { Rol } from "../rol/rol";

export class Auth_rol{
    usuarioRolId!:number;
    rol:Rol
}