import { Hoteles } from "../hoteles/hoteles";

export class EtiquetaHotel {
    idEtiquetaHoteles: number;
    etiqueta: string;
    hoteles: Hoteles[];
}