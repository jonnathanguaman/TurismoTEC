export interface ImagenesLugares{
    idImagenesLugar:number;
    url:string;
}