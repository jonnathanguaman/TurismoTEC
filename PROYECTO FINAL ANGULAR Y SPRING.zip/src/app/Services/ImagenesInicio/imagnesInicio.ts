export interface ImagenesInicio{
    idImagenInicio:number;
    url:string;
}