export interface EtiquetasLugar{
    idEtiqueta:number;
    etiqueta:string;
}