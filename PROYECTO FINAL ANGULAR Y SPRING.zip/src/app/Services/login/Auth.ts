export interface Auth{
    id_auth:number;
    username:String;
    password:String;
}