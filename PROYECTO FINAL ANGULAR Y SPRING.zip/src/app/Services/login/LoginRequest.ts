export interface LoginRequest{
    username:String;
    password:String;
}