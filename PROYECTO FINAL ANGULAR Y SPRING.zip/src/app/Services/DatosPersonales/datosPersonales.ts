export class DatosPersona{
    id_Usuario!:number;
    nombre!:string;
    apellido!:string;
    edad!:number;
    paisOrigen!:string;
    idioma!:string;
    correo!:string
}