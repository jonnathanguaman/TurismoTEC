export interface ImagenesRestaurantes{
    idImagenesRestaurantes:number;
    url:string;
}