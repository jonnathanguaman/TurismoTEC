import { EtiquetasLugar } from "../categoriasLugares/categoriaLugar"
import { Lugares } from "../Lugares/lugares"

export class Lugares_categoria{
    idLugaresEtiquetas:number
    etiquetas:EtiquetasLugar
    lugares:Lugares
}