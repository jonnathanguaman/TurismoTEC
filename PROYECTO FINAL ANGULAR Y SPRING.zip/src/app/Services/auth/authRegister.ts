export class authRegister{
    id_auth!:number;
    username!:string;
    password!:string;
    id_usuario!:number;
    authorities:string[]
}