export interface ImagenesHoteles{
    idImagenesHoteles:number;
    url:string;
}