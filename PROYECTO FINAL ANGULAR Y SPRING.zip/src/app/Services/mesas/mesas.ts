export interface Mesa{
    idMesa:number;
    numeroMesa:string;
    capacidad:string;
    disponibilidad:boolean;
}