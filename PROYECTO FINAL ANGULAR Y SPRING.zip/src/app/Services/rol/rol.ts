export interface Rol{
    rolId:number
    rolNombre:string
}